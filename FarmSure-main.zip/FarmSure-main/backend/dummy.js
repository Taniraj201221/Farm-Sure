// input is not defined
//     at signupHandler (SignUpForm.jsx:35:17)
//     at HTMLUnknownElement.callCallback2 (chunk-6VWAHX6D.js?v=610c3bf7:3674:22)
//     at Object.invokeGuardedCallbackDev (chunk-6VWAHX6D.js?v=610c3bf7:3699:24)
//     at invokeGuardedCallback (chunk-6VWAHX6D.js?v=610c3bf7:3733:39)
//     at invokeGuardedCallbackAndCatchFirstError (chunk-6VWAHX6D.js?v=610c3bf7:3736:33)
//     at executeDispatch (chunk-6VWAHX6D.js?v=610c3bf7:7014:11)
//     at processDispatchQueueItemsInOrder (chunk-6VWAHX6D.js?v=610c3bf7:7034:15)
//     at processDispatchQueue (chunk-6VWAHX6D.js?v=610c3bf7:7043:13)
//     at dispatchEventsForPlugins (chunk-6VWAHX6D.js?v=610c3bf7:7051:11)
//     at chunk-6VWAHX6D.js?v=610c3bf7:7174:20
// signupHandler @ SignUpForm.jsx:35
// callCallback2 @ chunk-6VWAHX6D.js?v=610c3bf7:3674
// invokeGuardedCallbackDev @ chunk-6VWAHX6D.js?v=610c3bf7:3699
// invokeGuardedCallback @ chunk-6VWAHX6D.js?v=610c3bf7:3733
// invokeGuardedCallbackAndCatchFirstError @ chunk-6VWAHX6D.js?v=610c3bf7:3736
// executeDispatch @ chunk-6VWAHX6D.js?v=610c3bf7:7014
// processDispatchQueueItemsInOrder @ chunk-6VWAHX6D.js?v=610c3bf7:7034
// processDispatchQueue @ chunk-6VWAHX6D.js?v=610c3bf7:7043
// dispatchEventsForPlugins @ chunk-6VWAHX6D.js?v=610c3bf7:7051
// (anonymous) @ chunk-6VWAHX6D.js?v=610c3bf7:7174
// batchedUpdates$1 @ chunk-6VWAHX6D.js?v=610c3bf7:18913
// batchedUpdates @ chunk-6VWAHX6D.js?v=610c3bf7:3579
// dispatchEventForPluginEventSystem @ chunk-6VWAHX6D.js?v=610c3bf7:7173
// dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay @ chunk-6VWAHX6D.js?v=610c3bf7:5478
// dispatchEvent @ chunk-6VWAHX6D.js?v=610c3bf7:5472
// dispatchDiscreteEvent @ chunk-6VWAHX6D.js?v=610c3bf7:5449
// Show 15 more frames
// Show lessUnderstand this error